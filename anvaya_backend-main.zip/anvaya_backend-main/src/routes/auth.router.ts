import { register, login } from "../controllers/auth.controller";
import express, {type Request, type Response } from "express";
import { asyncHandler } from "../utils/asyncHandler";
const authRouter = express.Router();

authRouter.post('/register',asyncHandler(register));
authRouter.post('/login',asyncHandler(login));
export {authRouter};