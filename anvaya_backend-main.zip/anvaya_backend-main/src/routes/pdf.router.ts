import express, { type Request, type Response, type NextFunction } from 'express';
import { upload, uploadAndIndexPDF, getPDFs, deletePDF } from '../controllers/pdf.controller';
import { verifyToken, checkRole } from '../middlewares/auth.middleware';
import { asyncHandler } from '../utils';
import multer from 'multer';

const pdfRouter = express.Router();
pdfRouter.use(asyncHandler(verifyToken));
pdfRouter.use(asyncHandler(checkRole('ADMIN')));

// Upload PDF
pdfRouter.post('/upload', (req: Request, res: Response, next: NextFunction) => {
  upload.single('file')(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      // A Multer error occurred when uploading
      return res.status(400).json({ message: `Multer error: ${err.message}` });
    } else if (err) {
      // An unknown error occurred
      return res.status(400).json({ message: err.message });
    }
    
    // Everything went fine, proceed
    next();
  });
}, asyncHandler(uploadAndIndexPDF));

// Get all PDFs for the admin
pdfRouter.get('/', asyncHandler(getPDFs));

// Delete PDF
pdfRouter.delete('/:pdfId', asyncHandler(deletePDF));

export { pdfRouter };