import express from "express";
import { chatWithRAG } from "../controllers/chat.controller";
import { asyncHandler } from "../utils";

const chatRouter = express.Router();

chatRouter.post("/", asyncHandler(chatWithRAG));

export { chatRouter };
