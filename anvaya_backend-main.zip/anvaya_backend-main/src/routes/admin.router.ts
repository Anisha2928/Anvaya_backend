import { 
    createOrganization, getOrganization, updateOrganization, deleteOrganization,
    createUser, getUsers, updateUser, deleteUser
} from "../controllers/admin.controller";
import express from "express";
import { asyncHandler } from "../utils/asyncHandler";
import { checkRole, verifyToken } from "../middlewares/auth.middleware";

const adminRouter = express.Router();
adminRouter.use(asyncHandler(verifyToken));
adminRouter.use(asyncHandler(checkRole("ADMIN")));


//  ORGANIZATION ROUTES 
adminRouter.post('/organization', asyncHandler(createOrganization));  
adminRouter.get('/organization', asyncHandler(getOrganization)); 
adminRouter.put('/organization', asyncHandler(updateOrganization));  
adminRouter.delete('/organization', asyncHandler(deleteOrganization));  

// USER ROUTES
adminRouter.post('/user', asyncHandler(createUser)); 
adminRouter.get('/users', asyncHandler(getUsers));  
adminRouter.put('/user/:userId', asyncHandler(updateUser));
adminRouter.delete('/user/:userId', asyncHandler(deleteUser));  

export { adminRouter };
