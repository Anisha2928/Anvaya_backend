import { test, expect,  } from "bun:test";
import axios, { AxiosError } from "axios";

const BASE_URL = "http://localhost:5000/api";
const TEST_USER = {
  firstName: "Test",
  lastName: "User",
  email: "testuser@example.com",
  password: "Password123!"
};

// Cleanup variable to track if we need to clean up test user
let cleanupRequired = false;

// ✅ Test Registration and Login
test("🔐 Should register a new admin user", async () => {
  console.log("\n🔄 Registering a new admin user...");
  try {
    const response = await axios.post(`${BASE_URL}/auth/register`, TEST_USER);
    
    expect(response.status).toBe(201);
    expect(response.data.message).toBe("User created successfully");
    expect(response.data.accessToken).toBeDefined();
    
    cleanupRequired = true;
    console.log("✅ Admin registration successful\n");
  } catch (error) {
    const axiosError = error as AxiosError<{ message: string }>;
    // If user already exists, this is fine for our tests
    if (axiosError.response?.status === 400 && axiosError.response?.data?.message === "Email already exists") {
      console.log("ℹ️ Test user already exists, continuing with login tests\n");
      cleanupRequired = true;
    } else {
      console.error("❌ Registration failed:", axiosError.response?.data || axiosError.message);
      throw error;
    }
  }
});

test("🔐 Should login with valid credentials", async () => {
  console.log("\n🔄 Logging in with valid credentials...");
  const response = await axios.post(`${BASE_URL}/auth/login`, {
    email: TEST_USER.email,
    password: TEST_USER.password
  });
  
  expect(response.status).toBe(200);
  expect(response.data.access_token).toBeDefined();
  
  console.log("✅ Login successful\n");
});

test("🔐 Should reject login with invalid password", async () => {
  console.log("\n🔄 Attempting login with invalid password...");
  try {
    await axios.post(`${BASE_URL}/auth/login`, {
      email: TEST_USER.email,
      password: "wrongpassword"
    });
    
    // Should not reach here
  } catch (error) {
    const axiosError = error as AxiosError<{ message: string }>;
    expect(axiosError.response?.status).toBe(401);
    expect(axiosError.response?.data?.message).toBe("Wrong Password");
    console.log("✅ Invalid password rejected as expected\n");
  }
});

test("🔐 Should reject login with non-existent user", async () => {
  console.log("\n🔄 Attempting login with non-existent user...");
  try {
    await axios.post(`${BASE_URL}/auth/login`, {
      email: "nonexistent@example.com",
      password: "password123"
    });
    
    // Should not reach here
    expect(true).toBe(false);
  } catch (error) {
    const axiosError = error as AxiosError<{ message: string }>;
    expect(axiosError.response?.status).toBe(404);
    expect(axiosError.response?.data?.message).toBe("User not found");
    console.log("✅ Non-existent user rejected as expected\n");
  }
});
