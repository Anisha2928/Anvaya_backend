import { test, expect, beforeAll, afterAll } from "bun:test";
import axios from "axios";
import { io, Socket } from "socket.io-client";
import fs from "fs";
import path from "path";
import FormData from "form-data";

const BASE_URL = "http://localhost:5000";
const TEST_USER = {
  firstName: "E2E",
  lastName: "Tester",
  email: "e2etester@example.com",
  password: "E2ETest!123"
};

let token: string;
let userId: string;
let organizationId: string;
let pdfId: string;
let socket: Socket;
let chatId: string;
const testPdfPath = path.join(process.cwd(), "test-resources", "e2e-test-document.pdf");

// ✅ Setup E2E test environment
beforeAll(async () => {
  console.log("\n🔄 Setting up E2E test environment...");

  // Ensure test directory exists
  const testDir = path.join(process.cwd(), "test-resources");
  if (!fs.existsSync(testDir)) {
    fs.mkdirSync(testDir, { recursive: true });
  }

  // Create a simple test PDF
  if (!fs.existsSync(testPdfPath)) {
    fs.writeFileSync(testPdfPath, "Test PDF Content");
  }
});

// ✅ Register or Login Test User
test("🔐 Should register or login test user", async () => {
  try {
    const response = await axios.post(`${BASE_URL}/api/auth/register`, TEST_USER);
    expect(response.status).toBe(201);
    token = response.data.accessToken;
  } catch (error: any) {
    if (error.response?.status === 400) {
      const loginRes = await axios.post(`${BASE_URL}/api/auth/login`, {
        email: TEST_USER.email,
        password: TEST_USER.password
      });
      token = loginRes.data.access_token;
    } else {
      throw error;
    }
  }
  
  // Extract user ID from token
  const tokenPayload = JSON.parse(Buffer.from(token.split(".")[1], "base64").toString());
  userId = tokenPayload.userId || tokenPayload.id;
});

// ✅ Create or Get Organization
test("🏢 Should create or fetch an organization", async () => {
  try {
    const response = await axios.post(
      `${BASE_URL}/api/admin/organization`,
      { name: "E2E Test Organization" },
      { headers: { Authorization: `Bearer ${token}` } }
    );
    expect(response.status).toBe(201);
    organizationId = response.data.organization.id;
  } catch (error: any) {
    if (error.response?.status === 400) {
      const orgRes = await axios.get(`${BASE_URL}/api/admin/organization`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      organizationId = orgRes.data.id;
    } else {
      throw error;
    }
  }
});

// ✅ Upload a PDF
test("📄 Should upload a test PDF", async () => {
  const form = new FormData();
  form.append("file", fs.createReadStream(testPdfPath));

  const response = await axios.post(`${BASE_URL}/api/pdf/upload`, form, {
    headers: { ...form.getHeaders(), Authorization: `Bearer ${token}` }
  });

  expect(response.status).toBe(201);
  pdfId = response.data.file.id;
});

// ✅ WebSocket Connection
test("🔌 Should connect to WebSocket", async () => {
  socket = io(BASE_URL, { auth: { token } });
  await new Promise<void>((resolve, reject) => {
    socket.on("connect", () => resolve());
    socket.on("connect_error", (err) => reject(err));
  });
});

// ✅ Create a Chat
test("💬 Should create a new chat", async () => {
  socket.emit("createChat", { userId });
  await new Promise<void>((resolve) => {
    socket.once("chatCreated", (data) => {
      chatId = data.chatId;
      expect(chatId).toBeDefined();
      resolve();
    });
  });
});

// ✅ Cleanup after all tests
afterAll(async () => {
  await axios.delete(`${BASE_URL}/api/pdf/${pdfId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  console.log("✅ Cleanup complete");
});
