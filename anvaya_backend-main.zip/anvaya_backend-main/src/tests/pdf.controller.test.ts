import { test, expect, beforeAll, afterAll } from "bun:test";
import axios from "axios";
import fs from "fs";
import path from "path";
import FormData from "form-data";

const BASE_URL = "http://localhost:5000/api/pdf";
let adminToken: string;
let testPdfId: string;
const testPdfPath = path.join(process.cwd(), "test-resources", "test-document.pdf");

// Create test PDF if it doesn't exist
beforeAll(async () => {
  console.log("\n🔄 Setting up test environment...");
  
  // Ensure test directory exists
  const testDir = path.join(process.cwd(), "test-resources");
  if (!fs.existsSync(testDir)) {
    fs.mkdirSync(testDir, { recursive: true });
  }
  
  // Create a simple test PDF if it doesn't exist
  if (!fs.existsSync(testPdfPath)) {
    console.log("Creating test PDF file...");
    // This is a very basic PDF structure that will work for testing
    const simplePdfContent = "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj 2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj 3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Contents 4 0 R/Resources<<>>>>endobj 4 0 obj<</Length 21>>stream\nBT /F1 12 Tf 100 700 Td (Test PDF) Tj ET\nendstream\nendobj\nxref\n0 5\n0000000000 65535 f\n0000000009 00000 n\n0000000056 00000 n\n0000000111 00000 n\n0000000212 00000 n\ntrailer<</Size 5/Root 1 0 R>>\nstartxref\n284\n%%EOF";
    fs.writeFileSync(testPdfPath, simplePdfContent);
  }

  // Login as admin
  console.log("\n🔄 Logging in as admin...");
  try {
    const loginRes = await axios.post("http://localhost:5000/api/auth/login", {
      email: "testuser@example.com",
      password: "Password123!"
    });

    adminToken = loginRes.data.access_token;
    console.log("✅ Admin login successful\n");
    
    // Create organization if needed for tests
    try {
      await axios.post(
        "http://localhost:5000/api/admin/organization",
        { name: "PDF Test Organization" },
        { headers: { Authorization: `Bearer ${adminToken}` } }
      );
      console.log("✅ Test organization created for PDF tests\n");
    } catch (error: any) {
      if (error.response?.status === 400 && error.response?.data?.message === "Admin can create only one organization") {
        console.log("ℹ️ Organization already exists, continuing with tests\n");
      } else {
        throw error;
      }
    }
  } catch (error: any) {
    console.error("❌ Admin login failed:", error.response?.data || error.message);
    throw new Error("Failed to set up test environment!");
  }
});

// ✅ Test PDF upload
test("📄 Should upload a PDF file", async () => {
  console.log("\n🔄 Uploading test PDF...");
  
  // Create form data with PDF
  const form = new FormData();
  form.append('file', fs.createReadStream(testPdfPath));
  
  const response = await axios.post(`${BASE_URL}/upload`, form, {
    headers: {
      ...form.getHeaders(),
      Authorization: `Bearer ${adminToken}`
    }
  });
  
  expect(response.status).toBe(201);
  expect(response.data.message).toBe("File uploaded successfully, indexing in progress");
  expect(response.data.file).toBeDefined();
  expect(response.data.file.id).toBeDefined();
  
  testPdfId = response.data.file.id;
  console.log("✅ PDF uploaded successfully\n");
});

// ✅ Test retrieving PDFs
test("📄 Should retrieve all uploaded PDFs", async () => {
  console.log("\n🔄 Retrieving all PDFs...");
  
  // Wait a moment for indexing to at least start
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  const response = await axios.get(BASE_URL, {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  
  expect(response.status).toBe(200);
  expect(Array.isArray(response.data)).toBe(true);
  expect(response.data.length).toBeGreaterThan(0);
  
  // Check if our test PDF is in the list
  const uploadedPdf = response.data.find((pdf: any) => pdf.id === testPdfId);
  expect(uploadedPdf).toBeDefined();
  
  console.log("✅ PDFs retrieved successfully\n");
});

// ✅ Test deleting PDF
test("📄 Should delete the uploaded PDF", async () => {
  console.log("\n🔄 Deleting test PDF...");
  
  const response = await axios.delete(`${BASE_URL}/${testPdfId}`, {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  
  expect(response.status).toBe(200);
  expect(response.data.message).toBe("PDF deleted successfully");
  
  console.log("✅ PDF deleted successfully\n");
});

// ✅ Verify PDF is deleted
test("📄 Should confirm PDF is deleted", async () => {
  console.log("\n🔄 Verifying PDF deletion...");
  
  const response = await axios.get(BASE_URL, {
    headers: { Authorization: `Bearer ${adminToken}` }
  });
  
  expect(response.status).toBe(200);
  
  // Check that our deleted PDF is not in the list
  const deletedPdf = response.data.find((pdf: any) => pdf.id === testPdfId);
  expect(deletedPdf).toBeUndefined();
  
  console.log("✅ PDF deletion verified\n");
});

// ✅ Cleanup after all tests
afterAll(async () => {
  try {
    // Clean up test organization
    await axios.delete("http://localhost:5000/api/admin/organization", {
      headers: { Authorization: `Bearer ${adminToken}` }
    });
    console.log("✅ Test organization cleaned up\n");
  } catch (error: any) {
    console.log("ℹ️ Note: Organization may have already been deleted in previous tests\n");
  }
  
  console.log("\n🚀 PDF management tests completed!\n");
});