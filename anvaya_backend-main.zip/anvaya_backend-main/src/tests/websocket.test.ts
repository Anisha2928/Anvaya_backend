// import { test, expect, beforeAll, afterAll } from "bun:test";
// import axios from "axios";
// import { io, Socket } from "socket.io-client";

// // Define interfaces for type safety
// interface ChatData {
//   chatId: string;
// }

// interface Message {
//   sender: "user" | "bot";
// }

// interface MessageUpdate {
//   isComplete: boolean;
// }

// interface Chat {
//   id: string;
// }

// const BASE_URL = "http://localhost:5000";
// let adminToken: string;
// let testUserId: string;
// let socket: Socket;
// let chatId: string;

// // Setup: Login as admin and initialize WebSocket
// beforeAll(async () => {
//   console.log("\n🔄 Setting up WebSocket test environment...");

//   try {
//     // 1. Login as admin
//     const loginRes = await axios.post(`${BASE_URL}/api/auth/login`, {
//       email: "testuser@example.com",
//       password: "Password123!",
//     });

//     adminToken = loginRes.data.access_token;
    
//     // 2. Decode JWT to get user ID
//     const tokenPayload = JSON.parse(
//       Buffer.from(adminToken.split(".")[1], "base64").toString()
//     );
//     testUserId = tokenPayload.userId || tokenPayload.id;
//     console.log(`✅ Using user ID: ${testUserId}\n`);

//     // 3. Create organization if needed
//     try {
//       await axios.post(
//         `${BASE_URL}/api/admin/organization`,
//         { name: "WebSocket Test Organization" },
//         { headers: { Authorization: `Bearer ${adminToken}` } }
//       );
//       console.log("✅ Test organization created for WebSocket tests\n");
//     } catch (error: any) {
//       if (error.response?.status === 400 && error.response?.data?.message.includes("Admin can create only one organization")) {
//         console.log("ℹ️ Organization already exists, continuing with tests\n");
//       } else {
//         throw error;
//       }
//     }

//     // 4. Initialize WebSocket connection
//     socket = io(BASE_URL, {
//       auth: { token: adminToken },
//     });

//     await new Promise<void>((resolve, reject) => {
//       socket.on("connect", () => {
//         console.log(`✅ Connected to WebSocket server with ID: ${socket.id}\n`);
//         resolve();
//       });
//       socket.on("connect_error", (err) => {
//         console.error("❌ Connection error:", err);
//         reject(err);
//       });
//     });
//   } catch (error: any) {
//     console.error("❌ WebSocket test setup failed:", error.response?.data || error.message);
//     throw new Error("Failed to set up WebSocket test environment!");
//   }
// });

// // ✅ Test WebSocket connection
// test("🔌 Should connect to WebSocket server", async () => {
//   expect(socket.connected).toBe(true);
// });

// // ✅ Test creating a new chat
// test("🔌 Should create a new chat", () => {
//   console.log("\n🔄 Creating a new chat...");
//   return new Promise<void>((resolve, reject) => {
//     const timeout = setTimeout(() => reject(new Error("Create chat timeout")), 5000);
    
//     socket.once("chatCreated", (data: ChatData) => {
//       clearTimeout(timeout);
//       console.log(`✅ Chat created with ID: ${data.chatId}\n`);
//       expect(data.chatId).toBeDefined();
//       chatId = data.chatId;
//       resolve();
//     });
    
//     socket.emit("createChat", { userId: testUserId });
//   });
// });

// // ✅ Test sending and receiving messages
// test("🔌 Should send and receive messages", async () => {
//   console.log("\n🔄 Sending test message...");

//   return new Promise<void>((resolve, reject) => {
//       const timeout = setTimeout(() => reject(new Error("Message response timeout")), 50000000);
      
//       let botTypingStarted = false;
//       let botTypingEnded = false;
//       let botMessageReceived = false;
//       let botMessageCompleted = false;

//       socket.on("botTyping", (isTyping) => {
//           if (isTyping) {
//               botTypingStarted = true;
//               console.log("✅ Bot started typing...");
//           } else if (!isTyping && botTypingStarted) {
//               botTypingEnded = true;
//               console.log("✅ Bot stopped typing...");
//           }
//       });

//       socket.on("newMessage", (message) => {
//           if (message.sender === "bot") {
//               botMessageReceived = true;
//               console.log("✅ Received bot message...");
//           }
//       });

//       socket.on("messageUpdate", (update) => {
//           if (update.isComplete) {
//               botMessageCompleted = true;
//               console.log("✅ Bot message completed...");
//               clearTimeout(timeout);
//               resolve();
//           }
//       });

//       socket.emit("sendMessage", {
//           chatId,
//           pdfId: "cm7rasahh0001fnbgim2bhzd9",  // ✅ Ensure pdfId is used
//           content: "Explain about the quantum state which they found in a simple manner"
//       });
//   });
// });

// // ✅ Test fetching chat history
// test("🔌 Should fetch chat history", async () => {
//     console.log("\n🔄 Fetching chat history...");
  
//     return new Promise<void>((resolve, reject) => {
//       const timeout = setTimeout(() => reject(new Error("Chat history timeout")), 10000);
  
//       socket.once("chatHistory", (messages) => {
//         console.log("✅ Received chat history...");
//         console.log(messages);
//         clearTimeout(timeout);
//         console.log(`✅ Received chat history with ${messages.length} messages`);
  
//         expect(Array.isArray(messages)).toBe(true);
//         expect(messages.length).toBeGreaterThan(0);
//         resolve();
//       });
  
//       // ✅ Delay fetching to ensure messages are stored
//       setTimeout(() => {
//         socket.emit("fetchChatHistory", { chatId, userId: testUserId });
//       }, 2000);
//     });
//   });
  
// // ✅ Cleanup and disconnect
// afterAll(() => {
//   console.log("\n🔄 Cleaning up WebSocket tests...");
//   if (socket && socket.connected) {
//     socket.disconnect();
//     console.log("✅ Disconnected from WebSocket server\n");
//   }
//   console.log("\n🚀 WebSocket tests completed!\n");
// });