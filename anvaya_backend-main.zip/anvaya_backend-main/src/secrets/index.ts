export const PORT = process.env.PORT!;
export const JWT_ACCESS_SECRET = process.env.JWT_ACCESS_SECRET!;
export const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET!;
export const GEMINI_API_KEY = process.env.GEMINI_API_KEY!;
export const PINECONE_API_KEY = process.env.PINECONE_API_KEY!;