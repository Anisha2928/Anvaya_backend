// index.ts - Main Server File with WebSocket Integration
import express, { type Request, type Response } from 'express';
import { createServer } from 'http';
import { Server } from 'socket.io';
import { authRouter } from './routes/auth.router';
import { adminRouter } from './routes/admin.router';
import { pdfRouter } from './routes/pdf.router';
import { chatRouter } from './routes/chat.router';
import { PORT } from './secrets';
import { prisma } from './config';
import cors from 'cors';
import path from 'path'
import { setupWebSocket } from './controllers/chat.controller';

const app = express();
const server = createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// Routes
app.use('/api/auth', authRouter);
app.use('/api/admin', adminRouter);
app.use('/api/pdf', pdfRouter);
app.use('/api/chat', chatRouter);
app.get('/', (req: Request, res: Response) => {
    res.status(200).json({ message: 'The server is working !!' });
});


// Setup WebSocket Events
setupWebSocket(io);

// Start Server
server.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});

// Disconnect Prisma on server stop
process.on('SIGINT', async () => {
    console.log('Received SIGINT signal, disconnecting Prisma...');
    await prisma.$disconnect();
    console.log('Prisma client disconnected');
    process.exit(0);
});

process.on('uncaughtException', async (err) => {
    console.error('Uncaught exception:', err);
    await prisma.$disconnect();
    process.exit(1);
});