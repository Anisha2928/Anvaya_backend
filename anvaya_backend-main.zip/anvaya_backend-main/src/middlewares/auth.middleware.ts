import { type Request, type Response, type NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { JWT_ACCESS_SECRET } from '../secrets';
interface TokenPayload {
    userId: string;
    role: string;
    email: string;
    iat: number;
    exp: number;
}

declare global {
    namespace Express {
        interface Request {
            user?: TokenPayload;
        }
    }
}

 const verifyToken = async (req: Request, res: Response, next: NextFunction): Promise<Response | void> => {
    try {
        const authHeader = req.headers.authorization;
        
        if (!authHeader || !authHeader.startsWith('Bearer ')) {
            return res.status(401).json({ message: 'No token provided' });
        }

        const token = authHeader.split(' ')[1];
        
        const decoded = jwt.verify(token, JWT_ACCESS_SECRET) as TokenPayload;
        
        req.user = decoded;
        next();
    } catch (error) {
        if (error instanceof jwt.TokenExpiredError) {
            return res.status(401).json({ message: 'Token expired' });
        }
        if (error instanceof jwt.JsonWebTokenError) {
            return res.status(401).json({ message: 'Invalid token' });
        }
        console.error('Token verification error:', error);
            res.status(500).json({ message: 'Internal server error' });
        }
    };

const checkRole = (requiredRole: string) => {
    return async (req: Request, res: Response, next: NextFunction): Promise<Response | void> => {
        if (!req.user) {
            return res.status(401).json({ message: 'Unauthorized' });
        }

        if (req.user.role !== requiredRole) {
            return res.status(403).json({ message: 'Unauthorized' });
        }

        next();
    };
};

export {verifyToken,checkRole}; 