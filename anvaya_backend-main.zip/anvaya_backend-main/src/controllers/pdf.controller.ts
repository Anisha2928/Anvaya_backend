import { type Request, type Response } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { prisma } from '../config';
import { indexPDF } from '../services/rag.service';

// Define a relative path for uploads
const uploadDir = path.join(process.cwd(), 'uploads/pdfs');

// Ensure uploads directory exists
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer Storage Configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir); 
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const originalName = file.originalname.replace(/\s+/g, '_');
    cb(null, `${path.parse(originalName).name}-${uniqueSuffix}${path.extname(originalName)}`);
  }
});

// File filter for PDFs
const fileFilter = (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
  if (file.mimetype === 'application/pdf') {
    cb(null, true);
  } else {
    cb(new Error('Only PDF files are allowed'));
  }
};

// Upload middleware
export const upload = multer({ 
  storage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 } 
});

// export const uploadAndIndexPDF = async (req: Request, res: Response) => {
//   try {
//     const adminId = req.user?.userId;
//     if (!adminId) {
//       return res.status(401).json({ message: 'Unauthorized' });
//     }

//     const file = req.file;
//     if (!file) {
//       return res.status(400).json({ message: 'No file uploaded or invalid file type' });
//     }
//     const filePath = path.join('uploads/pdfs', file.filename);
//     // Save PDF info to database
//     const uploadedFile = await prisma.pDF.create({
//       data: {
//         fileName: file.originalname,
//         filePath,
//         adminId,
//       },
//     });

//     res.status(201).json({ 
//       message: 'File uploaded successfully, indexing in progress', 
//       file: uploadedFile 
//     });

    
//     indexPDF(uploadedFile.id, file.path)
//       .then(() => {
//         console.log(`PDF ${uploadedFile.id} indexed successfully`);
//       })
//       .catch((error) => {
//         console.error(`Error indexing PDF ${uploadedFile.id}:`, error);
//       });
      
//   } catch (error) {
//     console.error('Error in PDF upload:', error);
//     return res.status(500).json({ message: 'Server error during upload' });
//   }
// };
export const uploadAndIndexPDF = async (req: Request, res: Response) => {
    try {
      const adminId = req.user?.userId;
      if (!adminId) {
        return res.status(401).json({ message: 'Unauthorized' });
      }
  
      const file = req.file;
      if (!file) {
        return res.status(400).json({ message: 'No file uploaded or invalid file type' });
      }
  
      // Fix file path to match actual upload directory
      const filePath = `uploads/pdfs/${file.filename}`;
  
      // Save PDF info to database
      const uploadedFile = await prisma.pDF.create({
        data: {
          fileName: file.originalname,
          filePath: filePath,  
          adminId,
        },
      });
  
      res.status(201).json({ 
        message: 'File uploaded successfully, indexing in progress', 
        file: uploadedFile 
      });
  
      // ✅ Index PDF with Logging for Debugging
      console.log(`Starting indexing for PDF ${uploadedFile.id} at path: ${filePath}`);
      indexPDF(uploadedFile.id, filePath)
        .then(() => {
          console.log(`✅ PDF ${uploadedFile.id} indexed successfully.`);
        })
        .catch((error) => {
          console.error(`❌ Error indexing PDF ${uploadedFile.id}:`, error);
        });
  
    } catch (error) {
      console.error('❌ Error in PDF upload:', error);
      return res.status(500).json({ message: 'Server error during upload' });
    }
  };
  
export const getPDFs = async (req: Request, res: Response) => {
  try {
    const adminId = req.user?.userId;
    if (!adminId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const pdfs = await prisma.pDF.findMany({
      where: { adminId },
      orderBy: { uploadedAt: 'desc' }
    });

    return res.status(200).json(pdfs);
  } catch (error) {
    console.error('Error fetching PDFs:', error);
    return res.status(500).json({ message: 'Server error' });
  }
};

export const deletePDF = async (req: Request, res: Response) => {
  try {
    const adminId = req.user?.userId;
    const { pdfId } = req.params;
    
    if (!adminId) {
      return res.status(401).json({ message: 'Unauthorized' });
    }

    const pdf = await prisma.pDF.findUnique({
      where: { id: pdfId }
    });

    if (!pdf) {
      return res.status(404).json({ message: 'PDF not found' });
    }

    if (pdf.adminId !== adminId) {
      return res.status(403).json({ message: 'Unauthorized to delete this PDF' });
    }


    if (fs.existsSync(pdf.filePath)) {
      fs.unlinkSync(pdf.filePath);
    }

    
    await prisma.pDF.delete({
      where: { id: pdfId }
    });

    return res.status(200).json({ message: 'PDF deleted successfully' });
  } catch (error) {
    console.error('Error deleting PDF:', error);
    return res.status(500).json({ message: 'Server error' });
  }
};