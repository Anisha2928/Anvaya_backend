import { type Request, type Response } from "express";
import { hashPassword, comparePassword } from "../utils/";
import {prisma} from "../config";
import { generateAccessToken, generateRefreshToken } from "../utils/";
import { PrismaClientKnownRequestError } from "@prisma/client/runtime/library";
const register = async(req: Request, res: Response) => {
    try{
        const {firstName, lastName, password, email} = req.body;
        if(!firstName || !lastName || !password || !email){
            return res.status(400).json({message:"Please provide all the fields"});
        }
        const user = await prisma.user.create({
            data: {
                email,
                firstName,
                lastName,
                role:'ADMIN',
                password: await hashPassword(password),
            },
            select:{
                id:true,
                email:true,
                firstName:true,
                lastName:true,
                role:true,
            }
        });

        if(user){
            const accessToken =  generateAccessToken(user);
            const refreshToken =  generateRefreshToken(user);
            res.cookie('refreshToken', refreshToken,{
                httpOnly: true, 
                secure: true,  
                sameSite: 'strict', 
                path: '/api/auth/refresh',
                maxAge: 7 * 24 * 60 * 60 * 1000 
            })
            return res.status(201).json({ message: "User created successfully", accessToken });
        }else{
            return res.status(500).json({message:"Failed to create user"});
        }

    }catch(err: any){
        if(err instanceof PrismaClientKnownRequestError){
            if(err.code === "P2002"){
                return res.status(400).json({message:"Email already exists"});
            }
        }
        return res.status(500).json({message:"Failed to create user. Server error"});
    }

}

const login = async (req: Request, res: Response) => {
    try{
        const {email, password} = req.body;
        if(!email || !password){
            return res.status(400).json({message:"Please provide all the fields"});
        }
        console.log(email,password);
        const user = await prisma.user.findUnique({
            where:{
                email:email,
            },
            select:{
                id:true,
                email:true,
                firstName:true,
                lastName:true,
                role:true,
                password:true,
            }
        });

        if(!user){
            return res.status(404).json({message:"User not found"});
        }

        const isPasswordCorrect = await comparePassword(password, user.password);
        if(!isPasswordCorrect){
            return res.status(401).json({message:"Wrong Password"});
        }
        const access_token = generateAccessToken(user);
        const refresh_token =  generateRefreshToken(user);
        // console.log('Access Token',accessToken);
        // console.log('Referesh Token',refreshToken);

        res.cookie('refreshToken', refresh_token, {
            httpOnly: true,
            secure: true,
            sameSite: 'strict',
            path: '/api/auth/refresh',
            maxAge: 7 * 24 * 60 * 60 * 1000
        });

        return res.status(200).json({access_token });
    }catch(err: any){
        return res.status(500).json({message:"Failed to login user. Server Error"});
    }
}
export {register, login};