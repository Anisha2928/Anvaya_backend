import { type Request, type Response } from 'express';
import { Server, Socket } from 'socket.io';
import { prisma } from '../config';
import { queryRAG } from '../services/rag.service';
import { GoogleGenerativeAI } from '@google/generative-ai';
import { GEMINI_API_KEY } from '../secrets';
const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
export const chatWithRAG = async (req: Request, res: Response) => {
    try {
      const { query, userId } = req.body;
  
      if (!query || !userId) {
        return res.status(400).json({ message: "Query and userId are required." });
      }
  
      console.log(`💬 Received chat query: "${query}" from user: ${userId}`);
  
      const response = await queryRAG(query, userId);
  
      return res.status(200).json({ response });
    } catch (error) {
      console.error("❌ Error processing chat request:", error);
      return res.status(500).json({ message: "Server error during chat." });
    }
  };
export const setupWebSocket = (io: Server) => {
    io.on('connection', (socket: Socket) => {
        console.log(`User connected: ${socket.id}`);
        
        // Handle user joining a specific chat room
        socket.on('joinChat', async ({ chatId, userId }) => {
            socket.join(chatId);
            console.log(`User ${userId} joined chat room ${chatId}`);
            
            // Check if chat exists, if not create it
            const chat = await prisma.chat.findUnique({
                where: { id: chatId }
            });
            
            if (!chat) {
                await prisma.chat.create({
                    data: {
                        id: chatId,
                        userId
                    }
                });
            }
        });
        

        // socket.on('sendMessage', async ({ chatId, userId, content }) => {
        //     try {
        //         // ✅ Save user message before emitting
        //         const userMessage = await prisma.message.create({ 
        //             data: { chatId, userId, sender: 'user', content } 
        //         });
        
        //         io.to(chatId).emit('newMessage', { 
        //             id: userMessage.id, 
        //             sender: 'user', 
        //             content, 
        //             timestamp: userMessage.createdAt 
        //         });
        
        //         io.to(chatId).emit('botTyping', true);
        
        //         const ragPrompt = await queryRAG(content, userId);
        //         const model = genAI.getGenerativeModel({ model: 'gemini-1.5-pro' });
        //         const responseStream = await model.generateContentStream(ragPrompt);
        
        //         let fullResponse = '';
        //         let botMessageId = Date.now().toString();
        //         let isFirstChunk = true;
        
        //         for await (const chunk of responseStream.stream) {
        //             const chunkText = chunk.text();
        //             fullResponse += chunkText;
        
        //             if (isFirstChunk) {
        //                 io.to(chatId).emit('newMessage', {
        //                     id: botMessageId,
        //                     sender: 'bot',
        //                     content: chunkText,
        //                     isComplete: false,
        //                     timestamp: new Date()
        //                 });
        //                 isFirstChunk = false;
        //             } else {
        //                 io.to(chatId).emit('messageUpdate', {
        //                     id: botMessageId,
        //                     content: fullResponse,
        //                     isComplete: false
        //                 });
        //             }
        //         }
        
        //         // ✅ Store bot response **before** marking it complete
        //         await prisma.message.create({ 
        //             data: { chatId, userId, sender: 'bot', content: fullResponse } 
        //         });
        
        //         io.to(chatId).emit('messageUpdate', {
        //             id: botMessageId,
        //             content: fullResponse,
        //             isComplete: true
        //         });
        
        //         io.to(chatId).emit('botTyping', false);
        
        //     } catch (error) {
        //         console.error('Error in chat processing:', error);
        //         io.to(chatId).emit('error', { message: 'Failed to process the message.' });
        //         io.to(chatId).emit('botTyping', false);
        //     }
        // });
        // // Fetch chat history for a specific chat
        // socket.on('fetchChatHistory', async ({ chatId, userId }) => {
        //     try {
        //         const messages = await prisma.message.findMany({ 
        //             where: { chatId, userId }, 
        //             orderBy: { createdAt: 'asc' } 
        //         });
                
        //         socket.emit('chatHistory', messages);
        //     } catch (error) {
        //         console.error('Error fetching chat history:', error);
        //         socket.emit('error', { message: 'Failed to load chat history.' });
        //     }
        // });
        
        // // Get all chats for a user
        // socket.on('fetchUserChats', async ({ userId }) => {
        //     try {
        //         const chats = await prisma.chat.findMany({
        //             where: { userId },
        //             orderBy: { updatedAt: 'desc' },
        //             include: {
        //                 messages: {
        //                     orderBy: { createdAt: 'desc' },
        //                     take: 1
        //                 }
        //             }
        //         });
                
        //         socket.emit('userChats', chats);
        //     } catch (error) {
        //         console.error('Error fetching user chats:', error);
        //         socket.emit('error', { message: 'Failed to load chats.' });
        //     }
        // });
        socket.on('sendMessage', async ({ chatId, pdfId, content }) => {  // ✅ Use pdfId
            try {
                const userMessage = await prisma.message.create({ 
                    data: {
                        sender: 'user',
                        content,
                        chat: {
                            connect: { id: chatId }
                        },
                        user: {
                            connect: { id: pdfId }
                        }
                    }
                });
        
                io.to(chatId).emit('newMessage', { 
                    id: userMessage.id, 
                    sender: 'user', 
                    content, 
                    timestamp: userMessage.createdAt 
                });
        
                io.to(chatId).emit('botTyping', true);
        
                // ✅ Use pdfId instead of userId
                const ragPrompt = await queryRAG(content, pdfId);
                const model = genAI.getGenerativeModel({ model: 'gemini-1.5-pro' });
                const responseStream = await model.generateContentStream(ragPrompt);
        
                let fullResponse = '';
                let botMessageId = Date.now().toString();
                let isFirstChunk = true;
        
                for await (const chunk of responseStream.stream) {
                    const chunkText = chunk.text();
                    fullResponse += chunkText;
        
                    if (isFirstChunk) {
                        io.to(chatId).emit('newMessage', {
                            id: botMessageId,
                            sender: 'bot',
                            content: chunkText,
                            isComplete: false,
                            timestamp: new Date()
                        });
                        isFirstChunk = false;
                    } else {
                        io.to(chatId).emit('messageUpdate', {
                            id: botMessageId,
                            content: fullResponse,
                            isComplete: false
                        });
                    }
                }
        
                // ✅ Store bot response **before** marking it complete
                await prisma.message.create({ 
                    data: {
                        sender: 'bot',
                        content: fullResponse,
                        chat: {
                            connect: { id: chatId }
                        },
                        user: {
                            connect: { id: pdfId }
                        }
                    }
                });
        
                io.to(chatId).emit('messageUpdate', {
                    id: botMessageId,
                    content: fullResponse,
                    isComplete: true
                });
        
                io.to(chatId).emit('botTyping', false);
        
            } catch (error) {
                console.error('Error in chat processing:', error);
                io.to(chatId).emit('error', { message: 'Failed to process the message.' });
                io.to(chatId).emit('botTyping', false);
            }
        });
        // Create a new chat
        socket.on('createChat', async ({ userId }) => {
            try {
                const chatId = `chat_${Date.now()}`;
                await prisma.chat.create({
                    data: {
                        id: chatId,
                        userId
                    }
                });
                
                socket.emit('chatCreated', { chatId });
                socket.join(chatId);
            } catch (error) {
                console.error('Error creating chat:', error);
                socket.emit('error', { message: 'Failed to create a new chat.' });
            }
        });
        
        socket.on('disconnect', () => {
            console.log(`User disconnected: ${socket.id}`);
        });
    });
};