import { type Request, type Response } from "express";
import { prisma } from "../config";
import { hashPassword } from "../utils";

const createOrganization = async (req: Request, res: Response) => {
    try {
        const adminId = req.user?.userId!;
        const admin = await prisma.user.findUnique({
            where: { id: adminId },
            include: { organization: true },
        });

        if (!admin || admin.role !== "ADMIN") {
            return res.status(403).json({ message: "Unauthorized" });
        }

        if (admin.organization) {
            return res.status(400).json({ message: "Admin can create only one organization" });
        }

        const { name } = req.body;
        if (!name) {
            return res.status(400).json({ message: "Please provide a name" });
        }

        const organization = await prisma.organization.create({
            data: {
                name,
                users: { connect: { id: admin.id } },
            },
        });

        return res.status(201).json({
            message: "Organization created successfully",
            organization,
        });
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};

// ✅ Get Organization
const getOrganization = async (req: Request, res: Response) => {
    try {
        const adminId = req.user?.userId!;
        const admin = await prisma.user.findUnique({
            where: { id: adminId },
            include: { organization: true },
        });

        if (!admin || admin.role !== "ADMIN") {
            return res.status(403).json({ message: "Unauthorized" });
        }

        if (!admin.organization) {
            return res.status(404).json({ message: "No organization found" });
        }

        return res.status(200).json(admin.organization);
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};

// ✅ Update Organization
const updateOrganization = async (req: Request, res: Response) => {
    try {
        const adminId = req.user?.userId!;
        const { name } = req.body;

        if (!name) {
            return res.status(400).json({ message: "Name is required" });
        }

        const admin = await prisma.user.findUnique({
            where: { id: adminId },
            include: { organization: true },
        });

        if (!admin || admin.role !== "ADMIN") {
            return res.status(403).json({ message: "Unauthorized" });
        }

        if (!admin.organization) {
            return res.status(404).json({ message: "No organization found" });
        }

        const updatedOrg = await prisma.organization.update({
            where: { id: admin.organization.id },
            data: { name },
        });

        return res.status(200).json({ message: "Organization updated", organization: updatedOrg });
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};

// ✅ Delete Organization (Deletes all users under it)
const deleteOrganization = async (req: Request, res: Response) => {
    try {
        const adminId = req.user?.userId!;
        const admin = await prisma.user.findUnique({
            where: { id: adminId },
            include: { organization: true },
        });

        if (!admin || admin.role !== "ADMIN") {
            return res.status(403).json({ message: "Unauthorized" });
        }

        if (!admin.organization) {
            return res.status(404).json({ message: "No organization found" });
        }

        await prisma.organization.delete({ where: { id: admin.organization.id } });

        return res.status(200).json({ message: "Organization deleted successfully" });
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};

// ✅ Create User (Email ID is the password)
const createUser = async (req: Request, res: Response) => {
    try {
        const adminId = req.user?.userId!;
        const admin = await prisma.user.findUnique({
            where: { id: adminId },
            include: { organization: true },
        });

        if (!admin || admin.role !== "ADMIN") {
            return res.status(403).json({ message: "Unauthorized" });
        }

        if (!admin.organization) {
            return res.status(400).json({ message: "Admin must create an organization first" });
        }

        const { firstName, lastName, email } = req.body;

        if (!firstName || !lastName || !email) {
            return res.status(400).json({ message: "All fields are required" });
        }

        const existingUser = await prisma.user.findUnique({ where: { email } });
        if (existingUser) {
            return res.status(400).json({ message: "User with this email already exists" });
        }

        const hashedPassword = await hashPassword(email);

        const user = await prisma.user.create({
            data: {
                firstName,
                lastName,
                email,
                password: hashedPassword,
                organizationId: admin.organization.id, 
                role: "USER",
            },
        });

        return res.status(201).json({ message: "User created successfully", user });
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};

// ✅ Get All Users in the Organization
const getUsers = async (req: Request, res: Response) => {
    try {
        const adminId = req.user?.userId!;
        const admin = await prisma.user.findUnique({
            where: { id: adminId },
            include: { organization: { include: { users: true } } },
        });

        if (!admin || admin.role !== "ADMIN") {
            return res.status(403).json({ message: "Unauthorized" });
        }

        if (!admin.organization) {
            return res.status(404).json({ message: "No organization found" });
        }

        return res.status(200).json(admin.organization.users);
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};

const deleteUser = async (req: Request, res: Response) => {
    try {
        const adminId = req.user?.userId!;
        const { userId } = req.params;

        const admin = await prisma.user.findUnique({
            where: { id: adminId },
            include: { organization: true },
        });

        if (!admin || admin.role !== "ADMIN") {
            return res.status(403).json({ message: "Unauthorized" });
        }

        if (!admin.organization) {
            return res.status(404).json({ message: "No organization found" });
        }

        const user = await prisma.user.findUnique({
            where: { id: userId },
        });

        if (!user || user.organizationId !== admin.organization.id) {
            return res.status(404).json({ message: "User not found or not in your organization" });
        }

        await prisma.user.delete({ where: { id: userId } });

        return res.status(200).json({ message: "User deleted successfully" });
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};

const updateUser = async (req: Request, res: Response) => {
    try {
        const adminId =req.user?.userId!;
        console.log("**********************");
        console.log(adminId);
        console.log("**********************");
        const { userId } = req.params;
        const { firstName, lastName, email, role } = req.body;

        const admin = await prisma.user.findUnique({
            where: { id: adminId },
            include: { organization: true },
        });

        if (!admin || admin.role !== "ADMIN") {
            return res.status(403).json({ message: "Unauthorized" });
        }

        if (!admin.organization) {
            return res.status(404).json({ message: "No organization found" });
        }

        const user = await prisma.user.findUnique({
            where: { id: userId },
        });

        if (!user || user.organizationId !== admin.organization.id) {
            return res.status(404).json({ message: "User not found or not in your organization" });
        }

        // Prevent admin from updating their own role
        if (user.id === admin.id && role && role !== "ADMIN") {
            return res.status(400).json({ message: "You cannot change your own role" });
        }

        // Update user data
        const updatedUser = await prisma.user.update({
            where: { id: userId },
            data: {
                firstName: firstName || user.firstName,
                lastName: lastName || user.lastName,
                email: email || user.email,
                role: role || user.role,
            },
        });

        return res.status(200).json({ message: "User updated successfully", updatedUser });
    } catch (err) {
        return res.status(500).json({ message: "Server error" });
    }
};


export {
    createOrganization,
    getOrganization,
    updateOrganization,
    deleteOrganization,
    createUser,
    getUsers,
    deleteUser,
    updateUser
};
