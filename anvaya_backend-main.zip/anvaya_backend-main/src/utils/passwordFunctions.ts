import argon2 from 'argon2';
const hashPassword = async (password: string):Promise<string> => {
    return await argon2.hash(password);
}

const comparePassword = async (password:string, userPassword:string):Promise<boolean> =>{

    return await argon2.verify(userPassword, password);
}

export {hashPassword, comparePassword};