import jwt from 'jsonwebtoken';
import {JWT_ACCESS_SECRET,JWT_REFRESH_SECRET} from "../secrets";
const generateAccessToken = (user: any) => {
    
    return  jwt.sign(
        { userId: user.id, email: user.email, role: user.role },
        JWT_ACCESS_SECRET as string,
        { expiresIn: '15m' }
    );
};
const generateRefreshToken =  (user: any) => {
    return jwt.sign(
        { userId: user.id, email: user.email, role: user.role },
        JWT_REFRESH_SECRET,
        { expiresIn: '7d' }
    );
};
const verifyRefreshToken =  (token: string) => {
    return  jwt.verify(token, JWT_REFRESH_SECRET);
};

export { generateAccessToken, generateRefreshToken, verifyRefreshToken };