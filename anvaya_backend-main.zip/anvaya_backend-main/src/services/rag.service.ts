import { Pinecone } from "@pinecone-database/pinecone";
import { PDFLoader } from "@langchain/community/document_loaders/fs/pdf";
import { GoogleGenerativeAIEmbeddings } from "@langchain/google-genai";
import { PineconeStore } from "@langchain/pinecone";
import { RecursiveCharacterTextSplitter } from "langchain/text_splitter";
import { PINECONE_API_KEY, GEMINI_API_KEY } from "../secrets";
import { GoogleGenerativeAI } from "@google/generative-ai";
import fs from "fs";

const PINECONE_INDEX_NAME = "anvaya";

// Initialize clients
const pinecone = new Pinecone({
  apiKey: PINECONE_API_KEY,
});

export const indexPDF = async (pdfId: string, filePath: string) => {
  try {
    console.log(`🔄 Indexing PDF ${pdfId} at path: ${filePath}`);

    // ✅ Check if File Exists
    if (!fs.existsSync(filePath)) {
      console.error(`❌ File not found at: ${filePath}`);
      throw new Error("PDF file not found for indexing");
    }

    // ✅ Load PDF
    console.log("📂 Loading PDF...");
    const loader = new PDFLoader(filePath);
    const rawDocs = await loader.load();

    console.log(`✅ Loaded PDF: ${rawDocs.length} pages found.`);

    // ✅ Split PDF into Chunks
    const textSplitter = new RecursiveCharacterTextSplitter({
      chunkSize: 1000,
      chunkOverlap: 200,
    });

    console.log("🔄 Splitting PDF into chunks...");
    const docs = await textSplitter.splitDocuments(rawDocs);
    console.log(`✅ PDF split into ${docs.length} chunks`);

    // ✅ Connect to Pinecone
    console.log("🔄 Connecting to Pinecone...");
    const pineconeIndex = pinecone.Index(PINECONE_INDEX_NAME);
    const embeddings = new GoogleGenerativeAIEmbeddings({
      apiKey: GEMINI_API_KEY,
      modelName: "embedding-001",
    });

    console.log("✅ Connected to Pinecone. Indexing chunks...");

    // ✅ Add Namespace & Check Metadata
    const docsWithMetadata = docs.map((doc, index) => ({
      pageContent: doc.pageContent,
      metadata: { pdfId, chunkIndex: index },
    }));

    console.log("📂 Sample chunk for indexing:", docsWithMetadata[0]);

    // ✅ Insert Data into Pinecone
    await PineconeStore.fromDocuments(docsWithMetadata, embeddings, {
      pineconeIndex,
      namespace: pdfId, // Ensure namespace is set to PDF ID
    });

    console.log(`✅ Successfully indexed PDF ${pdfId}`);
    return true;
  } catch (err) {
    console.error(`❌ Indexing error for PDF ${pdfId}:`, err);
    return false;
  }
};
export const queryRAG = async (query: string, pdfId: string) => {
  // ✅ Use pdfId, not userId
  try {
    console.log(
      `🔍 Searching for relevant documents for query: "${query}" in PDF: ${pdfId}`
    );

    // ✅ Initialize Pinecone and embeddings
    const pineconeIndex = pinecone.Index(PINECONE_INDEX_NAME);
    const embeddings = new GoogleGenerativeAIEmbeddings({
      apiKey: GEMINI_API_KEY,
      modelName: "text-embedding-004",
    });

    // ✅ Create vector store connection within the PDF namespace
    const vectorStore = await PineconeStore.fromExistingIndex(embeddings, {
      pineconeIndex,
      namespace: pdfId, // 🔹 Use pdfId as the namespace
    });

    // ✅ Perform similarity search
    const results = await vectorStore.similaritySearch(query, 5);

    if (!results.length) {
      console.log("❌ No relevant documents found.");
      return "I don't have enough information to answer this question.";
    }

    // ✅ Format retrieved context
    const context = results
      .map((r, i) => `[Document ${i + 1}]: ${r.pageContent}`)
      .join("\n\n");

    // ✅ Construct the final prompt
    const prompt = `
You are an AI assistant. Answer the user's question using ONLY the provided context. Do NOT use any outside knowledge.

---
📖 **Context:**  
${context}

---
❓ **User Question:**  
${query}

---
🚨 **Rules:**  
1. If the answer is in the context, provide a clear response.  
2. If the answer is **not in the context**, say:  
   👉 "The provided documents do not contain enough information to answer this question."  
3. Do **not** generate extra information. Only use what is given.

💡 **Answer:**
`;

    console.log("📝 Generated Prompt:\n", prompt);

    // ✅ Use Gemini AI to generate a response
    const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
    const response = await model.generateContent(prompt);

    // Extract and return the generated response
    const answer = response.response.text();
    console.log("🤖 AI Response:", answer);
    return answer;
  } catch (err) {
    console.error("❌ Query processing error:", err);
    throw err;
  }
};

// export const queryRAG = async (query: string, userId: string) => {
//     try {
//       console.log(`🔍 Searching for relevant documents for query: "${query}"`);

//       // ✅ Initialize Pinecone and embeddings
//       const pineconeIndex = pinecone.Index(PINECONE_INDEX_NAME);
//       const embeddings = new GoogleGenerativeAIEmbeddings({
//         apiKey: GEMINI_API_KEY,
//         modelName: "text-embedding-004",
//       });

//       // Create vector store connection
//       const vectorStore = await PineconeStore.fromExistingIndex(embeddings, {
//         pineconeIndex,
//         namespace: userId,  // 🔹 Ensure namespace is correctly set
//       });

//       //  Generate Query Embeddings
//       const queryEmbedding = await embeddings.embedQuery(query);
//       console.log("🔎 Generated Query Embedding:", queryEmbedding.slice(0, 5), "...");

//       //  Perform similarity search
//       const results = await vectorStore.similaritySearch(query, 5);

//       if (!results.length) {
//         console.log("❌ No relevant documents found.");
//         return "I don't have enough information to answer this question.";
//       }

//       //  Log the retrieved documents
//       console.log("📂 Retrieved Documents:", results);

//       // Format retrieved context
//       const context = results
//         .map((r, i) => `[Document ${i + 1}]: ${r.pageContent}`)
//         .join("\n\n");

//       // Construct the final prompt
//       const prompt = `
//   You are a helpful AI assistant. Answer the following question based only on the provided context.

//   Context:
//   ${context}

//   Question: ${query}

//   Instructions:
//   1. Use only the provided context to answer.
//   2. If the answer is not in the context, respond with "I don't have enough information to answer this question."
//   `;

//       console.log("📝 Generated Prompt:\n", prompt);

//       // Use Gemini AI to generate a response
//       const genAI = new GoogleGenerativeAI(GEMINI_API_KEY);
//       const model = genAI.getGenerativeModel({ model: "gemini-1.5-pro" });
//       const response = await model.generateContent(prompt);

//       // Extract and return the generated response
//       const answer = response.response.text();
//       console.log("🤖 AI Response:", answer);
//       return answer;
//     } catch (err) {
//       console.error("❌ Query processing error:", err);
//       throw err;
//     }
//   };
